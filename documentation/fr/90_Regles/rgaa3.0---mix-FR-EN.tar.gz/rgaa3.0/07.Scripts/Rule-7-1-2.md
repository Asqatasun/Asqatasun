# RGAA 3.0 -  Rule 7.1.2

## Summary

No-check rule

## Business description

### Criterion

[7.1](http://references.modernisation.gouv.fr/referentiel-technique-0#crit-7-1)

###Test

[7.1.2](http://references.modernisation.gouv.fr/referentiel-technique-0#test-7-1-2)

### Description

Chaque fonctionnalit&eacute; d'insertion de contenu contr&ocirc;l&eacute;e par un <a href="http://references.modernisation.gouv.fr/referentiel-technique-0#mScript">script</a> utilise-t-elle des <a href="http://references.modernisation.gouv.fr/referentiel-technique-0#mDomSpec">propri&eacute;t&eacute;s et m&eacute;thodes conformes &agrave; la sp&eacute;cification DOM (Document Object Model)</a> ?

### Level

**A**

## Technical description

### Scope

**Page**

### Decision level

**Semi-decidable**

## Algorithm

### Selection

### Process

### Analysis

#### No Tested 

In all cases
