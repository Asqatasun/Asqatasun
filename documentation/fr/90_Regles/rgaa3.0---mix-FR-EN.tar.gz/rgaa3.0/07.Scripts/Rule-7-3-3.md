# RGAA 3.0 -  Rule 7.3.3

## Summary

No-check rule

## Business description

### Criterion

[7.3](http://references.modernisation.gouv.fr/referentiel-technique-0#crit-7-3)

###Test

[7.3.3](http://references.modernisation.gouv.fr/referentiel-technique-0#test-7-3-3)

### Description

Un <a href="http://references.modernisation.gouv.fr/referentiel-technique-0#mScript">script</a> ne doit pas supprimer le `focus` d'un &eacute;l&eacute;ment qui le re&ccedil;oit. Cette r&egrave;gle est-elle respect&eacute;e (<a href="http://references.modernisation.gouv.fr/referentiel-technique-0#cpCrit7-3" title="Cas particuliers pour le crit&egrave;re 7.3">hors cas particuliers</a>) ?

### Level

**A**

## Technical description

### Scope

**Page**

### Decision level

**Semi-decidable**

## Algorithm

### Selection

### Process

### Analysis

#### No Tested 

In all cases

