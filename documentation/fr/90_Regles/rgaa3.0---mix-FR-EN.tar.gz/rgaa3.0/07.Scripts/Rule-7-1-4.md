# RGAA 3.0 -  Rule 7.1.4

## Summary

No-check rule

## Business description

### Criterion

[7.1](http://references.modernisation.gouv.fr/referentiel-technique-0#crit-7-1)

###Test

[7.1.4](http://references.modernisation.gouv.fr/referentiel-technique-0#test-7.1.4)

### Description

Chaque <a href="http://references.modernisation.gouv.fr/referentiel-technique-0#mModifRole">modification du r&ocirc;le natif</a> d'un &eacute;l&eacute;ment HTML respecte-t-elle les r&egrave;gles et pr&eacute;conisations indiqu&eacute;es dans la sp&eacute;cification HTML5 et les notes techniques associ&eacute;es ?

### Level

**A**

## Technical description

### Scope

**Page**

### Decision level

**Semi-decidable**

## Algorithm

### Selection

### Process

### Analysis

#### No Tested 

In all cases
