# RGAA 3.0 -  Rule 7.5.1

## Summary

No-check rule

## Business description

### Criterion

[7.5](http://references.modernisation.gouv.fr/referentiel-technique-0#crit-7-5)

###Test

[7.5.1](http://references.modernisation.gouv.fr/referentiel-technique-0#test-7-5-1)

### Description

Chaque <a href="http://references.modernisation.gouv.fr/referentiel-technique-0#mScript">script</a> qui provoque une <a href="http://references.modernisation.gouv.fr/referentiel-technique-0#mAlerte">alerte</a> non sollicit&eacute;e est-il contr&ocirc;lable par l'utilisateur (hors <a href="http://references.modernisation.gouv.fr/referentiel-technique-0#cpCrit7-6" title="Cas particuliers pour le crit&egrave;re 7.6">cas particuliers</a>) ?

### Level

**AAA**

## Technical description

### Scope

**Page**

### Decision level

**Semi-decidable**

## Algorithm

### Selection

### Process

### Analysis

#### No Tested 

In all cases
