# RGAA 3.0 -  Rule 8.2.2

## Summary

No-check rule

## Business description

### Criterion

[8.2](http://references.modernisation.gouv.fr/referentiel-technique-0#crit-8-2)

###Test

[8.2.2](http://references.modernisation.gouv.fr/referentiel-technique-0#test-8-2-2)

### Description

Pour chaque d&eacute;claration de <a href="http://references.modernisation.gouv.fr/referentiel-technique-0#mDTD">type de document</a>, le code source de la page ne doit pas utiliser d'&eacute;l&eacute;ments obsol&egrave;tes. Cette r&egrave;gle est-elle respect&eacute;e <a href="http://references.modernisation.gouv.fr/referentiel-technique-0#cpCrit8-2">hors cas particuliers</a> ?

### Level

**A**

## Technical description

### Scope

**Page**

### Decision level

**Semi-Decidable**

## Algorithm

### Selection

### Process

### Analysis

#### No Tested 

In all cases

