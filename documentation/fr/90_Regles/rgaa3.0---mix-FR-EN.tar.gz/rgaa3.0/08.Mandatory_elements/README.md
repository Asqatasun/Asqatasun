
# RGAA 3.0 Theme 8: Mandatory elements

## Criterion 8.1
* [Rule 8.1.1](Rule-8-1-1.md)
* [Rule 8.1.2](Rule-8-1-2.md)
* [Rule 8.1.3](Rule-8-1-3.md)

## Criterion 8.2
* [Rule 8.2.1](Rule-8-2-1.md)
* [Rule 8.2.2](Rule-8-2-2.md)

## Criterion 8.3
* [Rule 8.3.1](Rule-8-3-1.md)

## Criterion 8.4
* [Rule 8.4.1](Rule-8-4-1.md)

## Criterion 8.5
* [Rule 8.5.1](Rule-8-5-1.md)

## Criterion 8.6
* [Rule 8.6.1](Rule-8-6-1.md)

## Criterion 8.7
* [Rule 8.7.1](Rule-8-7-1.md)

## Criterion 8.8
* [Rule 8.8.1](Rule-8-8-1.md)
* [Rule 8.8.2](Rule-8-8-2.md)

## Criterion 8.9
* [Rule 8.9.1](Rule-8-9-1.md)

## Criterion 8.10
* [Rule 8.10.1](Rule-8-10-1.md)


