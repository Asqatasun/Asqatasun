# RGAA 3.0 -  Rule 4.7.1

## Summary

No-check rule

## Business description

### Criterion

[4.7](http://references.modernisation.gouv.fr/referentiel-technique-0#crit-4-7)

###Test

[4.7.1](http://references.modernisation.gouv.fr/referentiel-technique-0#test-4-7-1)

### Description

Chaque <a href="http://references.modernisation.gouv.fr/referentiel-technique-0#mMediaTemp">m&eacute;dia temporel</a> pr&eacute;-enregistr&eacute; seulement vid&eacute;o v&eacute;rifie-t-il, si n&eacute;cessaire, une de ces conditions (<a href="http://references.modernisation.gouv.fr/referentiel-technique-0#cpCrit4-" title="Cas particuliers pour le crit&egrave;re 4.7">hors cas particuliers</a>) ? 
 
 * Il existe une <a href="http://references.modernisation.gouv.fr/referentiel-technique-0#mAudioDesc">audio-description</a> synchronis&eacute;e 
 * Il existe une version alternative avec une <a href="http://references.modernisation.gouv.fr/referentiel-technique-0#mAudioDesc">audio-description</a> synchronis&eacute;e 


### Level

**AA**

## Technical description

### Scope

**Page**

### Decision level

**Semi-Decidable**

## Algorithm

### Selection

### Process

### Analysis

#### No Tested 

In all cases
