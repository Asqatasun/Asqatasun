
# RGAA 3.0 Theme 4: Multimedia


## Criterion 4.1
* [Rule 4.1.1](Rule-4-1-1.md)
* [Rule 4.1.2](Rule-4-1-2.md)
* [Rule 4.1.3](Rule-4-1-3.md)

## Criterion 4.2
* [Rule 4.2.1](Rule-4-2-1.md)
* [Rule 4.2.2](Rule-4-2-2.md)
* [Rule 4.2.3](Rule-4-2-3.md)

## Criterion 4.3
* [Rule 4.3.1](Rule-4-3-1.md)
* [Rule 4.3.2](Rule-4-3-2.md)

## Criterion 4.4
* [Rule 4.4.1](Rule-4-4-1.md)

## Criterion 4.5
* [Rule 4.5.1](Rule-4-5-1.md)
* [Rule 4.5.2](Rule-4-5-2.md)

## Criterion 4.6
* [Rule 4.6.1](Rule-4-6-1.md)
* [Rule 4.6.2](Rule-4-6-2.md)

## Criterion 4.7
* [Rule 4.7.1](Rule-4-7-1.md)
* [Rule 4.7.2](Rule-4-7-2.md)

## Criterion 4.8
* [Rule 4.8.1](Rule-4-8-1.md)
* [Rule 4.8.2](Rule-4-8-2.md)

## Criterion 4.9
* [Rule 4.9.1](Rule-4-9-1.md)
* [Rule 4.9.2](Rule-4-9-2.md)

## Criterion 4.10
* [Rule 4.10.1](Rule-4-10-1.md)
* [Rule 4.10.2](Rule-4-10-2.md)

## Criterion 4.11
* [Rule 4.11.1](Rule-4-11-1.md)
* [Rule 4.11.2](Rule-4-11-2.md)

## Criterion 4.12
* [Rule 4.12.1](Rule-4-12-1.md)
* [Rule 4.12.2](Rule-4-12-2.md)

## Criterion 4.13
* [Rule 4.13.1](Rule-4-13-1.md)
* [Rule 4.13.2](Rule-4-13-2.md)

## Criterion 4.14
* [Rule 4.14.1](Rule-4-14-1.md)
* [Rule 4.14.2](Rule-4-14-2.md)

## Criterion 4.15
* [Rule 4.15.1](Rule-4-15-1.md)
* [Rule 4.15.2](Rule-4-15-2.md)

## Criterion 4.16
* [Rule 4.16.1](Rule-4-16-1.md)
* [Rule 4.16.2](Rule-4-16-2.md)

## Criterion 4.17
* [Rule 4.17.1](Rule-4-17-1.md)

## Criterion 4.18
* [Rule 4.18.1](Rule-4-18-1.md)

## Criterion 4.19
* [Rule 4.19.1](Rule-4-19-1.md)

## Criterion 4.20
* [Rule 4.20.1](Rule-4-20-1.md)
* [Rule 4.20.2](Rule-4-20-2.md)
* [Rule 4.20.3](Rule-4-20-3.md)

## Criterion 4.21
* [Rule 4.21.1](Rule-4-21-1.md)
* [Rule 4.21.2](Rule-4-21-2.md)

## Criterion 4.22
* [Rule 4.22.1](Rule-4-22-1.md)
* [Rule 4.22.2](Rule-4-22-2.md)

