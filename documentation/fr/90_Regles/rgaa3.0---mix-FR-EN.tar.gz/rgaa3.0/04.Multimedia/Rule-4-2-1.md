# RGAA 3.0 -  Rule 4.2.1

## Summary

No-check rule

## Business description

### Criterion

[4.2](http://references.modernisation.gouv.fr/referentiel-technique-0#crit-4-2)

###Test

[4.2.1](http://references.modernisation.gouv.fr/referentiel-technique-0#test-4-2-1)

### Description

Pour chaque <a href="http://references.modernisation.gouv.fr/referentiel-technique-0#mMediaTemp">m&eacute;dia temporel</a> pr&eacute;-enregistr&eacute; seulement audio, ayant une <a href="http://references.modernisation.gouv.fr/referentiel-technique-0#mTranscriptTextuel">transcription textuelle</a>, celle-ci est-elle pertinente (<a href="http://references.modernisation.gouv.fr/referentiel-technique-0#cpCrit4-" title="Cas particuliers pour le crit&egrave;re 4.2">hors cas particuliers</a>) ?

### Level

**A**

## Technical description

### Scope

**Page**

### Decision level

**Semi-Decidable**

## Algorithm

### Selection

### Process

### Analysis

#### No Tested 

In all cases
