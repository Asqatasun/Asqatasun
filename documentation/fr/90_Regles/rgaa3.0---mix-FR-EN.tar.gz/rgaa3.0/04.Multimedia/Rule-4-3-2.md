# RGAA 3.0 -  Rule 4.3.2

## Summary

No-check rule

## Business description

### Criterion

[4.3](http://references.modernisation.gouv.fr/referentiel-technique-0#crit-4-3)

###Test

[4.3.2](http://references.modernisation.gouv.fr/referentiel-technique-0#test-4.3.2)

### Description

Pour chaque <a href="http://references.modernisation.gouv.fr/referentiel-technique-0#mMediaTemp">m&eacute;dia temporel</a> synchronis&eacute; pr&eacute;-enregistr&eacute; poss&eacute;dant des <a href="http://references.modernisation.gouv.fr/referentiel-technique-0#mSsTitreSynchro">sous-titres synchronis&eacute;s</a> diffus&eacute;s via une balise `track`, la balise `track` poss&egrave;de-t-elle un attribut `kind="captions"`

### Level

**A**

## Technical description

### Scope

**Page**

### Decision level

**Semi-Decidable**

## Algorithm

### Selection

### Process

### Analysis

#### No Tested 

In all cases
