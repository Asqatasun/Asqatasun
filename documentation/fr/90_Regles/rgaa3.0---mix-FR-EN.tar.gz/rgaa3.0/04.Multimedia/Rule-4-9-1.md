# RGAA 3.0 -  Rule 4.9.1

## Summary

No-check rule

## Business description

### Criterion

[4.9](http://references.modernisation.gouv.fr/referentiel-technique-0#crit-4-9)

###Test

[4.9.1](http://references.modernisation.gouv.fr/referentiel-technique-0#test-4-9-1)

### Description

Chaque <a href="http://references.modernisation.gouv.fr/referentiel-technique-0#mMediaTemp">m&eacute;dia temporel</a> pr&eacute;-enregistr&eacute; seulement audio a-t-il, si n&eacute;cessaire, une interpr&eacute;tation en langue des signes adapt&eacute;e &agrave; la langue du m&eacute;dia (<a href="http://references.modernisation.gouv.fr/referentiel-technique-0#cpCrit4-" title="Cas particuliers pour le crit&egrave;re 4.9">hors cas particuliers</a>) ?

### Level

**AAA**

## Technical description

### Scope

**Page**

### Decision level

**Semi-Decidable**

## Algorithm

### Selection

### Process

### Analysis

#### No Tested 

In all cases
