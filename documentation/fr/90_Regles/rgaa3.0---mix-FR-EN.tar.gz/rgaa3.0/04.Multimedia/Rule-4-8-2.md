# RGAA 3.0 -  Rule 4.8.2

## Summary

No-check rule

## Business description

### Criterion

[4.8](http://references.modernisation.gouv.fr/referentiel-technique-0#crit-4-8)

###Test

[4.8.2](http://references.modernisation.gouv.fr/referentiel-technique-0#test-4-8-2)

### Description

Pour chaque <a href="http://references.modernisation.gouv.fr/referentiel-technique-0#mMediaTemp">m&eacute;dia temporel</a> synchronis&eacute; ayant une <a href="http://references.modernisation.gouv.fr/referentiel-technique-0#mAudioDesc">audio-description</a> synchronis&eacute;e, celle-ci est-elle pertinente ?

### Level

**AA**

## Technical description

### Scope

**Page**

### Decision level

**Semi-Decidable**

## Algorithm

### Selection

### Process

### Analysis

#### No Tested 

In all cases
