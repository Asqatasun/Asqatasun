# RGAA 3.0 -  Rule 3.1.1

## Summary

No-check rule

## Business description

### Criterion

[3.1](http://references.modernisation.gouv.fr/referentiel-technique-0#crit-3-1)

###Test

[3.1.1](http://references.modernisation.gouv.fr/referentiel-technique-0#test-3-1-1)

### Description

Pour chaque mot ou ensemble de mots dont la mise en couleur est porteuse d'<a href="http://references.modernisation.gouv.fr/referentiel-technique-0#mInfoCouleur">information</a>, l'<a href="http://references.modernisation.gouv.fr/referentiel-technique-0#mInfoCouleur">information</a> ne doit pas &ecirc;tre donn&eacute;e uniquement par la couleur. Cette r&egrave;gle est-elle respect&eacute;e ?

### Level

**A**

## Technical description

### Scope

**Page**

### Decision level

**Semi-Decidable**

## Algorithm

### Selection

### Process

### Analysis

#### No Tested 

In all cases




