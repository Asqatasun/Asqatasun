# RGAA 3.0 -  Rule 9.3.3

## Summary

No-check rule

## Business description

### Criterion

[9.3](http://references.modernisation.gouv.fr/referentiel-technique-0#crit-9-3)

###Test

[9.3.3](http://references.modernisation.gouv.fr/referentiel-technique-0#test-9.3.3)

### Description

Dans chaque page Web, les informations regroup&eacute;es sous forme de listes de d&eacute;finitions utilisent-elles les balises `dl` et `dt`/`dd` ?

### Level

**A**

## Technical description

### Scope

**Page**

### Decision level

**Semi-Decidable**

## Algorithm

### Selection

### Process

### Analysis

#### No Tested 

In all cases
