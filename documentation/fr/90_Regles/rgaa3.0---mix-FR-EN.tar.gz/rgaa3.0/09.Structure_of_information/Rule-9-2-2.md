# RGAA 3.0 -  Rule 9.2.2

## Summary

No-check rule

## Business description

### Criterion

[9.2](http://references.modernisation.gouv.fr/referentiel-technique-0#crit-9-2)

###Test

[9.2.2](http://references.modernisation.gouv.fr/referentiel-technique-0#test-9-2-2)

### Description

Dans chaque page Web, <a href="http://references.modernisation.gouv.fr/referentiel-technique-0#mArboDoc">l'arborescence du document</a> est-elle coh&eacute;rente ?

### Level

**A**

## Technical description

### Scope

**Page**

### Decision level

**Semi-Decidable**

## Algorithm

### Selection

### Process

### Analysis

#### No Tested 

In all cases
