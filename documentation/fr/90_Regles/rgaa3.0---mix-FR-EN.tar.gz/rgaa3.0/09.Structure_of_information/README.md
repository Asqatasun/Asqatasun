
# RGAA 3.0 Theme 9: Structure of information

## Criterion 9.1
* [Rule 9.1.1](Rule-9-1-1.md)
* [Rule 9.1.2](Rule-9-1-2.md)
* [Rule 9.1.3](Rule-9-1-3.md)
* [Rule 9.1.4](Rule-9-1-4.md)

## Criterion 9.2
* [Rule 9.2.1](Rule-9-2-1.md)
* [Rule 9.2.2](Rule-9-2-2.md)

## Criterion 9.3
* [Rule 9.3.1](Rule-9-3-1.md)
* [Rule 9.3.2](Rule-9-3-2.md)
* [Rule 9.3.3](Rule-9-3-3.md)

## Criterion 9.4
* [Rule 9.4.1](Rule-9-4-1.md)

## Criterion 9.5
* [Rule 9.5.1](Rule-9-5-1.md)

## Criterion 9.6
* [Rule 9.6.1](Rule-9-6-1.md)
* [Rule 9.6.2](Rule-9-6-2.md)

