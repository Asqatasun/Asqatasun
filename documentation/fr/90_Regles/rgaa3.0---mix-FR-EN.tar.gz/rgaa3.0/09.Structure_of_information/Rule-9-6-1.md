# RGAA 3.0 -  Rule 9.6.1

## Summary

No-check rule

## Business description

### Criterion

[9.6](http://references.modernisation.gouv.fr/referentiel-technique-0#crit-9-6)

###Test

[9.6.1](http://references.modernisation.gouv.fr/referentiel-technique-0#test-9-6-1)

### Description

Dans chaque page Web, chaque citation courte utilise-t-elle une balise `q` ?

### Level

**A**

## Technical description

### Scope

**Page**

### Decision level

**Semi-Decidable**

## Algorithm

### Selection

### Process

### Analysis

#### No Tested 

In all cases
