# RGAA 3.0 -  Rule 9.6.2

## Summary

No-check rule

## Business description

### Criterion

[9.6](http://references.modernisation.gouv.fr/referentiel-technique-0#crit-9-6)

###Test

[9.6.2](http://references.modernisation.gouv.fr/referentiel-technique-0#test-9-6-2)

### Description

Dans chaque page Web, chaque bloc de citation utilise-t-il une balise `blockquote` ?

### Level

**A**

## Technical description

### Scope

**Page**

### Decision level

**Semi-Decidable**

## Algorithm

### Selection

### Process

### Analysis

#### No Tested 

In all cases
